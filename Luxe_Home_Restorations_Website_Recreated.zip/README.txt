LUXE HOME RESTORATIONS WEBSITE
===============================
This is a real responsive static website, not a screenshot/mockup.

Files:
- index.html — complete website

How to use:
1. Open index.html in a browser to preview it.
2. Upload the file to a static website host such as Netlify, GitHub Pages, or another host that supports HTML.
3. Replace the image URLs later with your own brand photography if desired.

The site includes working navigation, responsive mobile layout, Pinterest and Payhip links, category sections, featured collections, journal/blog area, and footer.
